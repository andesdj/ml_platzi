export const mockSidebarJson = JSON.stringify({ test: 'hi' });
export const mockBotChatMessage = { type: 'bot', content: 'hello' };
export const mockUserChatMessage = { type: 'user', content: 'hello' };
export const mockOptionsChatMessage = { type: 'options', content: [{ label: 'Texas', value: 'texas' }] };

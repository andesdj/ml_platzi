## Reporting a bug

If you encounter an issue with the Node.js library, you are welcome to submit a [bug report](https://github.com/watson-developer-cloud/assistant-demo/issues). Before that, please search for similar issues. It's possible somebody has already encountered this issue.
